# Grizard Data Merge addon registration.
from gramps.gen.plug._pluginreg import TOOL, TOOL_DBPROC, TOOL_MODE_GUI, STABLE
from gramps.gen.const import URL_MANUAL_PAGE, GRAMPS_LOCALE as glocale

_ = glocale.translation.gettext

register(
    TOOL,
    id="grizardmerge",
    name=_("Grizard Data Merge"),
    description=_(
        "Loads a GEDCOM file and finds people that may "
        "represent the same person for merging."
    ),
    version="0.1.0",
    gramps_target_version="6.0",
    status=STABLE,
    fname="grizardmerge.py",
    authors=["Brian Caudill"],
    authors_email=["brian@bocaudill.com"],
    category=TOOL_DBPROC,
    toolclass="GrizardMergeTool",
    optionclass="GrizardMergeToolOptions",
    tool_modes=[TOOL_MODE_GUI],
    help_url=URL_MANUAL_PAGE + "_-_Navigation#Tools",
)
